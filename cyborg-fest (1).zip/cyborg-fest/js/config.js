/* ==========================================================
   CYBORG//FEST 2026 — content config
   Edit this file to change dates, events, schedule and links.
   No build step needed.
   ========================================================== */
window.CYBORG_CONFIG = {
  name: 'CYBORG//FEST 2026',

  // Countdown target (ISO 8601, include timezone offset)
  start: '2026-12-12T09:00:00+05:30',
  dateLabel: '12 — 14 DEC 2026',
  venue: 'Innovation Arena · Main Campus — edit in js/config.js',

  // Contact + registration. Leave registerUrl empty to fall back to an email link.
  contact: 'hello@cyborgfest.example',
  registerUrl: '',

  events: [
    {
      name: 'HACKFORGE', kicker: '24-hr hackathon', cat: 'ARENA 01 — BUILD', color: '#00f0ff',
      blurb: 'A full-day build marathon. Pitch at sunrise, ship before the next one. Solve real problem statements with whatever stack you trust.',
      when: '24 HRS', prize: '₹1,00,000', team: '2 – 4',
      rules: ['Teams of 2–4 operators', 'Open-source libraries allowed', 'Live demo + 5 min pitch to judges']
    },
    {
      name: 'MECHA CLASH', kicker: 'robot combat', cat: 'ARENA 02 — BREAK', color: '#ff2bd6',
      blurb: 'Bring a bot, leave with scrap or glory. Weight-class brackets, a steel arena and zero mercy.',
      when: '2 DAYS', prize: '₹75,000', team: '3 – 5',
      rules: ['Weight classes: 5 kg and 15 kg', 'Safety inspection before every round', 'Double-elimination bracket']
    },
    {
      name: 'NEURAL NEXUS', kicker: 'AI / ML challenge', cat: 'ARENA 03 — LEARN', color: '#b6ff3c',
      blurb: 'A hidden dataset, a live leaderboard and six hours. Train, tune and out-predict every other team in the grid.',
      when: '6 HRS', prize: '₹60,000', team: '1 – 3',
      rules: ['Any framework; no pre-trained leaderboard hacks', 'Scored on a private test set', 'Top 3 explain their approach live']
    },
    {
      name: 'ZERO DAY CTF', kicker: 'capture the flag', cat: 'ARENA 04 — EXPLOIT', color: '#ff4d6d',
      blurb: 'Web, crypto, forensics, reversing. Find the flags before the clock — or the other teams — find you.',
      when: '8 HRS', prize: '₹50,000', team: '1 – 3',
      rules: ['Jeopardy-style board with dynamic scoring', 'No attacking the scoreboard or infra', 'Write-ups required for top 5']
    },
    {
      name: 'PIXEL RIOT', kicker: 'game jam', cat: 'ARENA 05 — PLAY', color: '#ffb02e',
      blurb: 'One theme drops at kickoff. Forty-eight hours later, a playable game. Art, code, sound — all fair game.',
      when: '48 HRS', prize: '₹40,000', team: '1 – 4',
      rules: ['Theme revealed at kickoff', 'Any engine; assets must be original or licensed', 'Public play-test on the final day']
    },
    {
      name: 'SKYBREAKER', kicker: 'drone racing', cat: 'ARENA 06 — FLY', color: '#8b5cff',
      blurb: 'FPV gates, tight corners and sub-second margins. Race your own quad or fly one of ours.',
      when: '1 DAY', prize: '₹45,000', team: '1',
      rules: ['Spec-class quads up to 5 inch', 'Time-trial qualifiers, head-to-head finals', 'Loaner drones available on request']
    }
  ],

  schedule: [
    { day: 'DAY 01', date: '12 DEC', items: [
      { time: '09:00', title: 'Opening Ceremony', tag: 'Main stage' },
      { time: '10:30', title: 'HACKFORGE kickoff', tag: 'Arena 01' },
      { time: '13:00', title: 'Keynote — The Augmented Engineer', tag: 'Talk' },
      { time: '15:00', title: 'ZERO DAY CTF opens', tag: 'Arena 04' },
      { time: '19:00', title: 'Neon Night · live DJ', tag: 'Social' }
    ]},
    { day: 'DAY 02', date: '13 DEC', items: [
      { time: '09:30', title: 'MECHA CLASH qualifiers', tag: 'Arena 02' },
      { time: '11:00', title: 'NEURAL NEXUS dataset drop', tag: 'Arena 03' },
      { time: '14:00', title: 'Workshop — Edge AI on a microcontroller', tag: 'Workshop' },
      { time: '16:00', title: 'PIXEL RIOT theme reveal', tag: 'Arena 05' },
      { time: '18:30', title: 'SKYBREAKER time trials', tag: 'Arena 06' }
    ]},
    { day: 'DAY 03', date: '14 DEC', items: [
      { time: '09:00', title: 'HACKFORGE final demos', tag: 'Arena 01' },
      { time: '11:30', title: 'MECHA CLASH finals', tag: 'Arena 02' },
      { time: '14:00', title: 'PIXEL RIOT public play-test', tag: 'Arena 05' },
      { time: '16:00', title: 'SKYBREAKER finals', tag: 'Arena 06' },
      { time: '18:00', title: 'Awards & Closing', tag: 'Main stage' }
    ]}
  ]
};
