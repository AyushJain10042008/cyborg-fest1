/* ==========================================================
   CYBORG//FEST 2026 — 3D scene (Three.js)
   Scroll flies the camera along a spline through:
   cyborg eye-core → hex gates → six arena nodes → DNA helix → portal
   ========================================================== */
import * as THREE from 'three';
import { EffectComposer } from 'three/addons/postprocessing/EffectComposer.js';
import { RenderPass } from 'three/addons/postprocessing/RenderPass.js';
import { UnrealBloomPass } from 'three/addons/postprocessing/UnrealBloomPass.js';
import { OutputPass } from 'three/addons/postprocessing/OutputPass.js';
import { RoomEnvironment } from 'three/addons/environments/RoomEnvironment.js';

const clamp = (v, a, b) => Math.min(b, Math.max(a, v));
const lerp = (a, b, t) => a + (b - a) * t;

export function createScene({ canvas, state, events, reduce, coarse, onStats }) {
  const W = () => window.innerWidth, H = () => window.innerHeight;

  /* ---------- renderer ---------- */
  const renderer = new THREE.WebGLRenderer({ canvas, antialias: false, powerPreference: 'high-performance' });
  let pr = Math.min(window.devicePixelRatio || 1, coarse ? 1.5 : 2);
  renderer.setPixelRatio(pr);
  renderer.setSize(W(), H(), false);
  renderer.toneMapping = THREE.ACESFilmicToneMapping;
  renderer.toneMappingExposure = 1.05;

  const BG = 0x03040a;
  const scene = new THREE.Scene();
  scene.background = new THREE.Color(BG);
  scene.fog = new THREE.FogExp2(BG, 0.016);
  scene.environment = new THREE.PMREMGenerator(renderer).fromScene(new RoomEnvironment(), 0.04).texture;

  const camera = new THREE.PerspectiveCamera(60, W() / H(), 0.1, 400);

  /* ---------- accent tinting ---------- */
  const accent = new THREE.Color('#00f0ff');
  const accentTarget = new THREE.Color('#00f0ff');
  let lastAccent = '#00f0ff';
  const tint = [];
  const reg = (color, k = 1) => { tint.push({ c: color, k }); };
  const meshMat = (k = 1, opacity = 1) => {
    const m = new THREE.MeshBasicMaterial({ transparent: opacity < 1, opacity });
    reg(m.color, k); return m;
  };
  const lineMat = (k = 1, opacity = 1) => {
    const m = new THREE.LineBasicMaterial({ transparent: opacity < 1, opacity });
    reg(m.color, k); return m;
  };

  const glowTex = (() => {
    const c = document.createElement('canvas'); c.width = c.height = 128;
    const g = c.getContext('2d');
    const gr = g.createRadialGradient(64, 64, 0, 64, 64, 64);
    gr.addColorStop(0, 'rgba(255,255,255,1)');
    gr.addColorStop(0.25, 'rgba(255,255,255,.35)');
    gr.addColorStop(1, 'rgba(255,255,255,0)');
    g.fillStyle = gr; g.fillRect(0, 0, 128, 128);
    const t = new THREE.CanvasTexture(c); t.colorSpace = THREE.SRGBColorSpace; return t;
  })();

  /* ---------- lights ---------- */
  scene.add(new THREE.AmbientLight(0x8899bb, 0.35));
  const key = new THREE.DirectionalLight(0xffffff, 1.1); key.position.set(4, 6, 8); scene.add(key);

  /* ---------- camera path ---------- */
  const curve = new THREE.CatmullRomCurve3([
    new THREE.Vector3(0, 0, 9),
    new THREE.Vector3(0, 0.2, 2),
    new THREE.Vector3(-1.2, 0.4, -12),
    new THREE.Vector3(1.2, -0.3, -30),
    new THREE.Vector3(-1, 0.5, -50),
    new THREE.Vector3(1, -0.4, -70),
    new THREE.Vector3(-0.6, 0.3, -92),
    new THREE.Vector3(0, 0, -114)
  ], false, 'centripetal');
  const UP = new THREE.Vector3(0, 1, 0);
  function frame(t) {
    t = clamp(t, 0, 1);
    const P = curve.getPointAt(t);
    const T = curve.getTangentAt(t).normalize();
    const R = new THREE.Vector3().crossVectors(T, UP).normalize();
    const U = new THREE.Vector3().crossVectors(R, T).normalize();
    return { P, T, R, U };
  }
  const around = (f, ang, r, ry = r) =>
    f.P.clone().addScaledVector(f.R, Math.cos(ang) * r).addScaledVector(f.U, Math.sin(ang) * ry);

  /* ==========================================================
     1. CYBORG EYE-CORE
     ========================================================== */
  const core = new THREE.Group(); scene.add(core);
  const spin = new THREE.Group(); core.add(spin);

  const shellGeo = new THREE.IcosahedronGeometry(1.45, 1);
  spin.add(new THREE.Mesh(shellGeo, new THREE.MeshStandardMaterial({
    color: 0x151b2b, metalness: 0.95, roughness: 0.3, flatShading: true,
    transparent: true, opacity: 0.3, side: THREE.DoubleSide, envMapIntensity: 0.9
  })));
  spin.add(new THREE.LineSegments(new THREE.EdgesGeometry(shellGeo), lineMat(1)));
  const outer = new THREE.LineSegments(new THREE.EdgesGeometry(new THREE.OctahedronGeometry(2, 1)), lineMat(0.5, 0.5));
  core.add(outer);

  const iris = new THREE.Mesh(new THREE.SphereGeometry(0.68, 48, 48),
    new THREE.MeshStandardMaterial({ color: 0x02070d, roughness: 0.2, metalness: 0.4 }));
  reg(iris.material.emissive, 0.9);
  core.add(iris);

  // gaze group: pupil cap + iris rings follow the pointer
  const gaze = new THREE.Group(); core.add(gaze);
  const capGeo = new THREE.SphereGeometry(0.69, 32, 16, 0, Math.PI * 2, 0, 0.5);
  capGeo.rotateX(Math.PI / 2);
  gaze.add(new THREE.Mesh(capGeo, new THREE.MeshBasicMaterial({ color: 0x000000 })));
  const ringAt = (th, k, tube = 0.008) => {
    const m = new THREE.Mesh(new THREE.TorusGeometry(0.69 * Math.sin(th), tube, 8, 96), meshMat(k));
    m.position.z = 0.69 * Math.cos(th); gaze.add(m);
  };
  ringAt(0.5, 1.8, 0.012); ringAt(0.9, 1.0); ringAt(1.3, 0.7); ringAt(1.75, 0.45);

  const orbit = [];
  [[1.85, 0.014, [0.3, 0, 0], 1.3], [2.35, 0.01, [1.2, 0.4, 0], 0.8], [2.8, 0.008, [0.6, 1.1, 0], 0.55]]
    .forEach(([r, t, rot, k]) => {
      const ring = new THREE.Mesh(new THREE.TorusGeometry(r, t, 8, 200), meshMat(k));
      ring.rotation.set(...rot);
      const sat = new THREE.Mesh(new THREE.SphereGeometry(0.07, 12, 12), new THREE.MeshBasicMaterial({ color: 0xffffff }));
      sat.position.x = r; ring.add(sat);
      core.add(ring); orbit.push(ring);
    });

  const coreGlow = new THREE.Sprite(new THREE.SpriteMaterial({
    map: glowTex, transparent: true, opacity: 0.5, blending: THREE.AdditiveBlending, depthWrite: false
  }));
  reg(coreGlow.material.color, 1); coreGlow.scale.setScalar(8); core.add(coreGlow);

  const coreLight = new THREE.PointLight(0xffffff, 30, 16, 2); reg(coreLight.color, 1); core.add(coreLight);
  const coreHit = new THREE.Mesh(new THREE.SphereGeometry(2, 12, 12), new THREE.MeshBasicMaterial({ visible: false }));
  core.add(coreHit);

  const shock = new THREE.Mesh(new THREE.RingGeometry(0.98, 1, 96),
    new THREE.MeshBasicMaterial({ transparent: true, opacity: 0, side: THREE.DoubleSide, depthWrite: false, blending: THREE.AdditiveBlending }));
  reg(shock.material.color, 1.6); shock.visible = false; core.add(shock);

  let coreBase = 1;
  function layout() {
    const asp = W() / H();
    if (asp > 1.15) { core.position.set(3.4, 0, 0); coreBase = 1; }
    else { core.position.set(0, -2.4, 0); coreBase = 0.7; }
  }

  /* ==========================================================
     2. HEX GATES, PARTICLES, DEBRIS (the tunnel)
     ========================================================== */
  const gateMat = lineMat(0.8, 0.5);
  const gates = new THREE.Group(); scene.add(gates);
  for (let i = 0; i < 30; i++) {
    const f = frame(0.015 + (i / 30) * 0.97);
    const r = 5.5 + (i % 3) * 0.8, pts = [];
    for (let a = 0; a < 6; a++) pts.push(around(f, (a / 6) * Math.PI * 2 + i * 0.2, r));
    gates.add(new THREE.LineLoop(new THREE.BufferGeometry().setFromPoints(pts), gateMat));
  }

  const PN = coarse ? 1800 : 3200;
  const ppos = new Float32Array(PN * 3);
  for (let i = 0; i < PN; i++) {
    const p = around(frame(Math.random()), Math.random() * Math.PI * 2, 3 + Math.pow(Math.random(), 0.6) * 22);
    ppos.set([p.x, p.y, p.z], i * 3);
  }
  const pgeo = new THREE.BufferGeometry(); pgeo.setAttribute('position', new THREE.BufferAttribute(ppos, 3));
  const pmat = new THREE.PointsMaterial({
    size: 0.22, map: glowTex, transparent: true, opacity: 0.85, depthWrite: false,
    blending: THREE.AdditiveBlending, sizeAttenuation: true
  });
  scene.add(new THREE.Points(pgeo, pmat));

  const DN = coarse ? 60 : 130;
  const debrisMat = new THREE.MeshStandardMaterial({ color: 0x1b2338, metalness: 0.9, roughness: 0.3, flatShading: true });
  reg(debrisMat.emissive, 0.12);
  const debris = new THREE.InstancedMesh(new THREE.OctahedronGeometry(0.16), debrisMat, DN);
  debris.frustumCulled = false; scene.add(debris);
  const dData = Array.from({ length: DN }, () => ({
    p: around(frame(Math.random()), Math.random() * Math.PI * 2, 4.5 + Math.random() * 10),
    r: [Math.random() * 1.2, Math.random() * 1.2, Math.random() * 1.2],
    s: 0.5 + Math.random() * 1.6
  }));
  const dummy = new THREE.Object3D();

  /* ==========================================================
     3. ARENA NODES (clickable)
     ========================================================== */
  const geos = [
    new THREE.OctahedronGeometry(0.62),
    new THREE.TorusKnotGeometry(0.4, 0.13, 96, 12),
    new THREE.IcosahedronGeometry(0.6, 0),
    new THREE.DodecahedronGeometry(0.58),
    new THREE.BoxGeometry(0.8, 0.8, 0.8),
    new THREE.TorusGeometry(0.46, 0.17, 16, 32)
  ];
  const nodesGroup = new THREE.Group(); scene.add(nodesGroup);
  const nodes = [], hits = [];
  events.forEach((ev, i) => {
    const f = frame(0.325 + i * 0.042);
    const pos = around(f, i * 1.1 + 0.4, 3.3, 2.6);
    const col = new THREE.Color(ev.color);
    const geo = geos[i % geos.length];
    const g = new THREE.Group(); g.position.copy(pos);
    const mesh = new THREE.Mesh(geo, new THREE.MeshStandardMaterial({
      color: col.clone().multiplyScalar(0.25), emissive: col, emissiveIntensity: 0.35,
      metalness: 0.8, roughness: 0.25, flatShading: true, envMapIntensity: 0.9
    }));
    const wire = new THREE.LineSegments(new THREE.EdgesGeometry(geo, 25), new THREE.LineBasicMaterial({ color: col, transparent: true, opacity: 0.9 }));
    wire.scale.setScalar(1.12);
    const halo = new THREE.Mesh(new THREE.TorusGeometry(1.0, 0.012, 8, 96), new THREE.MeshBasicMaterial({ color: col, transparent: true, opacity: 0.45 }));
    const glow = new THREE.Sprite(new THREE.SpriteMaterial({ map: glowTex, color: col, transparent: true, opacity: 0.35, blending: THREE.AdditiveBlending, depthWrite: false }));
    glow.scale.setScalar(3.2);
    const hit = new THREE.Mesh(new THREE.SphereGeometry(1.25, 10, 10), new THREE.MeshBasicMaterial({ visible: false }));
    hit.userData.idx = i;
    g.add(mesh, wire, halo, glow, hit); nodesGroup.add(g); hits.push(hit);
    nodes.push({ g, mesh, halo, base: pos.clone(), phase: i * 1.3, s: 1, e: 0.35 });
  });
  let hoverIdx = -1;

  /* ==========================================================
     4. DNA HELIX (timeline)
     ========================================================== */
  const HN = reduce ? 70 : 110, hA = 0.62, hB = 0.83, HR = 2.3;
  const hFrames = Array.from({ length: HN }, (_, k) => frame(hA + ((hB - hA) * k) / (HN - 1)));
  const helixGroup = new THREE.Group(); scene.add(helixGroup);
  const helixMat = new THREE.MeshBasicMaterial({ color: 0xffffff }); reg(helixMat.color, 1.2);
  const strands = new THREE.InstancedMesh(new THREE.SphereGeometry(0.075, 10, 10), helixMat, HN * 2);
  strands.frustumCulled = false;
  const c1 = new THREE.Color(1, 1, 1), c2 = new THREE.Color(0.55, 0.55, 0.55);
  for (let k = 0; k < HN; k++) { strands.setColorAt(k * 2, c1); strands.setColorAt(k * 2 + 1, c2); }
  helixGroup.add(strands);
  const rungCount = Math.floor(HN / 3);
  const rungPos = new Float32Array(rungCount * 6);
  const rungGeo = new THREE.BufferGeometry(); rungGeo.setAttribute('position', new THREE.BufferAttribute(rungPos, 3));
  const rungs = new THREE.LineSegments(rungGeo, lineMat(0.8, 0.5)); rungs.frustumCulled = false;
  helixGroup.add(rungs);
  const tmpA = new THREE.Vector3(), tmpB = new THREE.Vector3();
  function updateHelix(time) {
    let r = 0;
    for (let k = 0; k < HN; k++) {
      const f = hFrames[k], a = k * 0.33 + time * 0.7;
      for (let s = 0; s < 2; s++) {
        const aa = a + s * Math.PI;
        dummy.position.copy(f.P).addScaledVector(f.R, Math.cos(aa) * HR).addScaledVector(f.U, Math.sin(aa) * HR);
        dummy.rotation.set(0, 0, 0);
        dummy.scale.setScalar(0.8 + 0.5 * Math.sin(k * 0.4 - time * 2));
        dummy.updateMatrix(); strands.setMatrixAt(k * 2 + s, dummy.matrix);
        if (s === 0) tmpA.copy(dummy.position); else tmpB.copy(dummy.position);
      }
      if (k % 3 === 0 && r < rungCount) { tmpA.toArray(rungPos, r * 6); tmpB.toArray(rungPos, r * 6 + 3); r++; }
    }
    strands.instanceMatrix.needsUpdate = true; rungGeo.attributes.position.needsUpdate = true;
  }

  /* ==========================================================
     5. PORTAL (registration)
     ========================================================== */
  const endF = frame(1);
  const portal = new THREE.Group();
  portal.position.copy(endF.P).addScaledVector(endF.T, 14); portal.lookAt(endF.P); scene.add(portal);
  const pRingMat = meshMat(1.3, 0.8);
  const pRingGeo = new THREE.TorusGeometry(3.6, 0.03, 8, 120);
  const pRings = Array.from({ length: 16 }, () => { const m = new THREE.Mesh(pRingGeo, pRingMat); portal.add(m); return m; });
  portal.add(new THREE.Mesh(new THREE.SphereGeometry(0.55, 24, 24), new THREE.MeshBasicMaterial({ color: 0xffffff })));
  const pGlow = new THREE.Sprite(new THREE.SpriteMaterial({ map: glowTex, transparent: true, opacity: 0.7, blending: THREE.AdditiveBlending, depthWrite: false }));
  reg(pGlow.material.color, 1); pGlow.scale.setScalar(11); portal.add(pGlow);

  /* ---------- post-processing ---------- */
  const rt = new THREE.WebGLRenderTarget(W() * pr, H() * pr, { type: THREE.HalfFloatType, samples: coarse ? 0 : 4 });
  const composer = new EffectComposer(renderer, rt);
  composer.setPixelRatio(pr); composer.setSize(W(), H());
  composer.addPass(new RenderPass(scene, camera));
  const bloom = new UnrealBloomPass(new THREE.Vector2(W(), H()), 0.85, 0.6, 0.12);
  composer.addPass(bloom);
  composer.addPass(new OutputPass());

  function resize() {
    renderer.setSize(W(), H(), false);
    composer.setPixelRatio(pr); composer.setSize(W(), H());
    camera.aspect = W() / H(); camera.updateProjectionMatrix();
    layout();
  }
  window.addEventListener('resize', resize);
  layout();

  /* ---------- picking ---------- */
  const ray = new THREE.Raycaster(), v2 = new THREE.Vector2();
  const aim = (x, y) => { v2.set((x / W()) * 2 - 1, -(y / H()) * 2 + 1); ray.setFromCamera(v2, camera); };

  /* ---------- loop ---------- */
  const clock = new THREE.Clock();
  const white = new THREE.Color(1, 1, 1);
  const sp = reduce ? 0.25 : 1;
  let time = 0, cur = state.t, fov = 60, pulseT = 0;
  let accT = 0, frames = 0, lowCount = 0;

  function tick() {
    if (document.hidden) { clock.getDelta(); return; }
    const dt = Math.min(clock.getDelta(), 0.05);
    time += dt;

    // accent
    if (state.accent !== lastAccent) { accentTarget.set(state.accent); lastAccent = state.accent; }
    accent.lerp(accentTarget, 1 - Math.exp(-dt * 4));
    for (const t of tint) t.c.copy(accent).multiplyScalar(t.k);
    pmat.color.copy(accent).lerp(white, 0.5);

    // camera along the spline
    const prev = cur;
    cur += (state.t - cur) * (1 - Math.exp(-dt * 5));
    const vel = Math.abs(cur - prev) / Math.max(dt, 1e-3);
    fov = lerp(fov, 60 + clamp(vel * 120, 0, 20), 1 - Math.exp(-dt * 6));
    if (Math.abs(camera.fov - fov) > 0.02) { camera.fov = fov; camera.updateProjectionMatrix(); }
    const f = frame(cur);
    camera.position.copy(f.P);
    camera.position.x += state.mx * 0.35; camera.position.y += state.my * 0.2;
    camera.lookAt(f.P.x + f.T.x * 6, f.P.y + f.T.y * 6, f.P.z + f.T.z * 6);
    camera.rotateZ(state.mx * -0.03);

    // gating (cheap visibility culling by progress)
    core.visible = cur < 0.3;
    nodesGroup.visible = cur > 0.18 && cur < 0.75;
    helixGroup.visible = cur > 0.5 && cur < 0.95;
    portal.visible = cur > 0.75;

    // core
    if (core.visible) {
      pulseT = Math.max(0, pulseT - dt * 0.9);
      core.scale.setScalar(coreBase * (1 + pulseT * 0.15));
      spin.rotation.y += dt * 0.15 * sp; spin.rotation.x += dt * 0.05 * sp;
      outer.rotation.y -= dt * 0.1 * sp; outer.rotation.z += dt * 0.05 * sp;
      orbit.forEach((r, i) => { r.rotation.z += dt * (0.35 + i * 0.2) * (1 + pulseT * 6) * sp; });
      gaze.rotation.y = lerp(gaze.rotation.y, state.mx * 0.7, 0.08);
      gaze.rotation.x = lerp(gaze.rotation.x, -state.my * 0.5, 0.08);
      core.rotation.y = lerp(core.rotation.y, state.mx * 0.18, 0.05);
      core.rotation.x = lerp(core.rotation.x, -state.my * 0.1, 0.05);
      shock.visible = pulseT > 0;
      if (shock.visible) { shock.scale.setScalar(1 + (1 - pulseT) * 9); shock.material.opacity = pulseT * 0.9; }
    }
    bloom.strength = 0.85 + pulseT * 1.4;

    // arena nodes
    if (nodesGroup.visible) {
      nodes.forEach((n, i) => {
        const hov = i === hoverIdx;
        n.s = lerp(n.s, hov ? 1.35 : 1, 0.12); n.g.scale.setScalar(n.s);
        n.e = lerp(n.e, hov ? 1.5 : 0.35, 0.12); n.mesh.material.emissiveIntensity = n.e;
        n.mesh.rotation.y += dt * (hov ? 2.2 : 0.5) * sp; n.mesh.rotation.x += dt * 0.3 * sp;
        n.halo.rotation.x = time * 0.6; n.halo.rotation.y = time * 0.3;
        n.g.position.y = n.base.y + Math.sin(time * 0.9 + n.phase) * 0.18 * (reduce ? 0.3 : 1);
      });
    }

    if (helixGroup.visible) updateHelix(time * sp);

    if (portal.visible) {
      pRings.forEach((m, j) => {
        const d = ((time * 2.2 * sp + j) % 16) - 3;
        m.position.z = -d; m.scale.setScalar(Math.max(0.02, 1 - d / 17)); m.rotation.z = j * 0.3 + time * 0.2 * sp;
      });
    }

    // debris drift
    for (let i = 0; i < DN; i++) {
      const d = dData[i];
      dummy.position.copy(d.p);
      dummy.rotation.set(time * d.r[0] * sp, time * d.r[1] * sp, time * d.r[2] * sp);
      dummy.scale.setScalar(d.s); dummy.updateMatrix(); debris.setMatrixAt(i, dummy.matrix);
    }
    debris.instanceMatrix.needsUpdate = true;

    composer.render(dt);

    // stats + adaptive quality
    accT += dt; frames++;
    if (accT >= 0.25) {
      const fps = frames / accT; accT = 0; frames = 0;
      onStats && onStats({ fps, z: camera.position.z, fov: camera.fov });
      if (fps < 26 && pr > 1) { if (++lowCount >= 6) { pr = 1; resize(); lowCount = 0; } } else lowCount = 0;
    }
  }
  renderer.setAnimationLoop(tick);

  return {
    pick(x, y) { aim(x, y); const h = ray.intersectObjects(hits, false); return h.length ? h[0].object.userData.idx : -1; },
    pickCore(x, y) { aim(x, y); return ray.intersectObject(coreHit, false).length > 0; },
    setHover(i) { hoverIdx = i; },
    pulse() { pulseT = 1; }
  };
}
