/* ==========================================================
   CYBORG//FEST 2026 — app wiring
   scroll → camera progress, UI, modal, loader, interactions
   ========================================================== */
import { createScene } from './scene.js';

const CFG = window.CYBORG_CONFIG;
const $ = (s, r = document) => r.querySelector(s);
const $$ = (s, r = document) => [...r.querySelectorAll(s)];
const clamp = (v, a, b) => Math.min(b, Math.max(a, v));
const reduce = matchMedia('(prefers-reduced-motion: reduce)').matches;
const coarse = matchMedia('(pointer: coarse)').matches;
const body = document.body;

const state = { t: 0, mx: 0, my: 0, accent: '#00f0ff' };

/* ---------- content from config ---------- */
$('#dates').textContent = CFG.dateLabel;
$('#venue').textContent = CFG.venue;
const mail = `mailto:${CFG.contact}?subject=${encodeURIComponent('CYBORG//FEST registration')}`;
const regUrl = CFG.registerUrl || mail;
const regBtn = $('#registerBtn'); regBtn.href = regUrl;
if (!CFG.registerUrl) regBtn.removeAttribute('target');
$('#contact').href = `mailto:${CFG.contact}`;

/* ---------- split title into letters ---------- */
let ci = 0;
$$('[data-split]').forEach(el => {
  const txt = el.textContent; el.textContent = ''; el.setAttribute('aria-hidden', 'true');
  [...txt].forEach(ch => {
    const s = document.createElement('span');
    s.className = 'ch'; s.textContent = ch; s.style.setProperty('--i', ci++);
    el.appendChild(s);
  });
});

/* ---------- countdown ---------- */
const target = new Date(CFG.start).getTime();
const pad = n => String(n).padStart(2, '0');
function tickCountdown() {
  let d = Math.max(0, target - Date.now()) / 1000;
  $('#cd-d').textContent = pad(Math.floor(d / 86400));
  $('#cd-h').textContent = pad(Math.floor(d % 86400 / 3600));
  $('#cd-m').textContent = pad(Math.floor(d % 3600 / 60));
  $('#cd-s').textContent = pad(Math.floor(d % 60));
}
tickCountdown(); setInterval(tickCountdown, 1000);

/* ---------- event chips + modal ---------- */
const modal = $('#modal');
let lastFocus = null;
function openEvent(i) {
  const ev = CFG.events[i]; if (!ev) return;
  lastFocus = document.activeElement;
  modal.style.setProperty('--ev', ev.color);
  $('#m-cat').textContent = '// ' + ev.cat;
  $('#m-name').textContent = ev.name;
  $('#m-blurb').textContent = ev.blurb;
  $('#m-when').textContent = ev.when;
  $('#m-prize').textContent = ev.prize;
  $('#m-team').textContent = ev.team;
  const list = $('#m-list'); list.innerHTML = '';
  ev.rules.forEach(r => { const li = document.createElement('li'); li.textContent = r; list.appendChild(li); });
  const r = $('#m-reg'); r.href = regUrl;
  if (CFG.registerUrl) r.target = '_blank'; else r.removeAttribute('target');
  modal.classList.add('open'); modal.setAttribute('aria-hidden', 'false');
  body.classList.add('modal-open');
  setTimeout(() => $('#m-close').focus(), 50);
}
function closeModal() {
  if (!modal.classList.contains('open')) return;
  modal.classList.remove('open'); modal.setAttribute('aria-hidden', 'true');
  body.classList.remove('modal-open');
  lastFocus && lastFocus.focus && lastFocus.focus();
}
modal.addEventListener('click', e => { if (e.target.closest('[data-close]')) closeModal(); });
addEventListener('keydown', e => {
  if (e.key === 'Escape') closeModal();
  if (e.key === 'Tab' && modal.classList.contains('open')) {
    const f = $$('button, a[href]', modal).filter(x => x.offsetParent !== null);
    if (!f.length) return;
    const first = f[0], last = f[f.length - 1];
    if (e.shiftKey && document.activeElement === first) { e.preventDefault(); last.focus(); }
    else if (!e.shiftKey && document.activeElement === last) { e.preventDefault(); first.focus(); }
  }
});

const chips = $('#chips');
CFG.events.forEach((ev, i) => {
  const b = document.createElement('button');
  b.className = 'chip'; b.setAttribute('role', 'listitem'); b.style.setProperty('--c', ev.color);
  b.innerHTML = `<span class="n">${String(i + 1).padStart(2, '0')}</span><span class="t"></span><span class="k"></span>`;
  $('.t', b).textContent = ev.name; $('.k', b).textContent = ev.kicker;
  b.addEventListener('click', () => openEvent(i));
  chips.appendChild(b);
});

/* ---------- schedule tabs ---------- */
const tabs = $('#tabs'), tl = $('#timeline');
function showDay(d) {
  $$('.tab', tabs).forEach((t, i) => t.setAttribute('aria-selected', i === d));
  tl.innerHTML = '';
  CFG.schedule[d].items.forEach((it, i) => {
    const li = document.createElement('li'); li.style.animationDelay = i * 70 + 'ms';
    const t = document.createElement('time'); t.textContent = it.time;
    const b = document.createElement('b'); b.textContent = it.title;
    const s = document.createElement('small'); s.textContent = it.tag;
    li.append(t, b, s); tl.appendChild(li);
  });
}
CFG.schedule.forEach((day, i) => {
  const b = document.createElement('button');
  b.className = 'tab'; b.setAttribute('role', 'tab');
  b.textContent = `${day.day} · ${day.date}`;
  b.addEventListener('click', () => showDay(i));
  tabs.appendChild(b);
});
showDay(0);

/* ---------- reveal + counters ---------- */
function countUp(el) {
  const end = +el.dataset.count, suf = el.dataset.suffix || '';
  if (reduce) { el.textContent = end + suf; return; }
  const t0 = performance.now();
  (function step(now) {
    const p = clamp((now - t0) / 1400, 0, 1), e = 1 - Math.pow(1 - p, 3);
    el.textContent = Math.round(end * e) + suf;
    if (p < 1) requestAnimationFrame(step);
  })(t0);
}
const io = new IntersectionObserver(es => es.forEach(e => {
  if (!e.isIntersecting) return;
  e.target.classList.add('in'); io.unobserve(e.target);
  $$('[data-count]', e.target).forEach(countUp);
}), { threshold: 0.15 });
$$('.reveal').forEach(el => io.observe(el));

/* ---------- 3D tilt on panels ---------- */
if (!coarse && !reduce) {
  $$('.tilt').forEach(el => {
    el.addEventListener('pointermove', e => {
      const r = el.getBoundingClientRect(), x = (e.clientX - r.left) / r.width, y = (e.clientY - r.top) / r.height;
      el.style.setProperty('--ry', ((x - 0.5) * 10).toFixed(2) + 'deg');
      el.style.setProperty('--rx', ((0.5 - y) * 10).toFixed(2) + 'deg');
      el.style.setProperty('--gx', x * 100 + '%'); el.style.setProperty('--gy', y * 100 + '%');
    });
    el.addEventListener('pointerleave', () => { el.style.setProperty('--rx', '0deg'); el.style.setProperty('--ry', '0deg'); });
  });
}

/* ---------- nav / rail / sections ---------- */
const sections = $$('main > section');
const railItems = $('#railItems');
sections.forEach(s => {
  const a = document.createElement('a'); a.href = '#' + s.id;
  a.innerHTML = '<span></span>'; $('span', a).textContent = s.dataset.label; a.tabIndex = -1;
  railItems.appendChild(a);
});
const burger = $('#burger'), navLinks = $('#navLinks');
burger.addEventListener('click', () => {
  const o = navLinks.classList.toggle('open'); burger.setAttribute('aria-expanded', o);
});
$$('a', navLinks).forEach(a => a.addEventListener('click', () => { navLinks.classList.remove('open'); burger.setAttribute('aria-expanded', false); }));

const sweep = $('#transition');
let current = '';
function hexToRgb(h) { const n = parseInt(h.slice(1), 16); return [n >> 16, n >> 8 & 255, n & 255].join(','); }
function setSection(sec) {
  if (sec.id === current) return;
  const first = current === ''; current = sec.id;
  body.dataset.section = sec.id;
  state.accent = sec.dataset.accent;
  const root = document.documentElement.style;
  root.setProperty('--accent', state.accent);
  root.setProperty('--accent-rgb', hexToRgb(state.accent));
  $$('.nav-links a:not(.nav-cta)').forEach(a => a.classList.toggle('on', a.getAttribute('href') === '#' + sec.id));
  $$('a', railItems).forEach((a, i) => a.classList.toggle('on', sections[i] === sec));
  if (!first && !reduce) { sweep.classList.remove('run'); void sweep.offsetWidth; sweep.classList.add('run'); }
}
sweep.addEventListener('animationend', () => sweep.classList.remove('run'));

function onScroll() {
  const max = document.documentElement.scrollHeight - innerHeight;
  state.t = max > 0 ? clamp(scrollY / max, 0, 1) : 0;
  $('.rail').style.setProperty('--p', state.t.toFixed(4));
  let cur = sections[0];
  for (const s of sections) if (s.getBoundingClientRect().top <= innerHeight * 0.5) cur = s;
  setSection(cur);
}
addEventListener('scroll', onScroll, { passive: true });
addEventListener('resize', onScroll);
onScroll();

/* ---------- pointer, cursor, picking ---------- */
const cursor = $('.cursor'), ring = $('.cursor-ring'), tip = $('#tip'), tipName = $('#tip-name');
let cx = 0, cy = 0, rx = 0, ry = 0, world = null;
if (!coarse) document.documentElement.classList.add('has-cursor');

addEventListener('pointermove', e => {
  state.mx = (e.clientX / innerWidth) * 2 - 1;
  state.my = -((e.clientY / innerHeight) * 2 - 1);
  cx = e.clientX; cy = e.clientY;
  if (coarse) return;
  cursor.style.transform = `translate(${cx}px,${cy}px)`;
  const over = e.target.closest && e.target.closest('a,button,.panel,.chip');
  ring.classList.toggle('active', !!over);
  if (world && !over && !body.classList.contains('modal-open')) {
    const i = world.pick(e.clientX, e.clientY);
    world.setHover(i);
    body.classList.toggle('over-node', i >= 0);
    if (i >= 0) { tipName.textContent = CFG.events[i].name; tip.style.transform = `translate(${cx + 18}px,${cy + 18}px)`; }
    tip.classList.toggle('show', i >= 0);
  } else { tip.classList.remove('show'); world && world.setHover(-1); body.classList.remove('over-node'); }
}, { passive: true });
(function followRing() {
  rx += (cx - rx) * 0.16; ry += (cy - ry) * 0.16;
  ring.style.transform = `translate(${rx}px,${ry}px)`;
  requestAnimationFrame(followRing);
})();

addEventListener('click', e => {
  if (!world || e.target.closest('a,button,.panel,.chip,#modal')) return;
  const i = world.pick(e.clientX, e.clientY);
  if (i >= 0) { openEvent(i); return; }
  if (state.t < 0.3 && world.pickCore(e.clientX, e.clientY)) {
    world.pulse();
    const t = $('#title'); t.classList.remove('glitch-now'); void t.offsetWidth; t.classList.add('glitch-now');
  }
});

/* ---------- 3D scene ---------- */
const fpsEl = $('#t-fps'), zEl = $('#t-z'), fovEl = $('#t-fov');
try {
  world = createScene({
    canvas: $('#webgl'), state, events: CFG.events, reduce, coarse,
    onStats: s => {
      fpsEl.textContent = Math.round(s.fps);
      zEl.textContent = (s.z >= 0 ? '+' : '') + s.z.toFixed(1);
      fovEl.textContent = Math.round(s.fov);
    }
  });
} catch (err) {
  console.warn('WebGL unavailable — showing fallback', err);
  document.documentElement.classList.add('no-webgl');
}

/* ---------- boot loader ---------- */
const lines = [
  '> mounting neural interface ........ OK',
  '> calibrating optic sensor ......... OK',
  '> loading six arenas ............... OK',
  '> syncing helix timeline ........... OK',
  '> SYSTEM ONLINE'
];
const boot = $('#boot'), bar = $('#bar'), loader = $('#loader');
let finished = false;
function finish() {
  if (finished) return; finished = true;
  bar.style.width = '100%';
  loader.classList.add('done');
  body.classList.remove('loading'); body.classList.add('ready');
  onScroll();
}
loader.addEventListener('click', finish);
if (reduce) { boot.textContent = lines.join('\n'); setTimeout(finish, 200); }
else {
  let n = 0;
  (function next() {
    if (finished) return;
    boot.textContent = lines.slice(0, ++n).join('\n');
    bar.style.width = (n / lines.length) * 100 + '%';
    n < lines.length ? setTimeout(next, 330) : setTimeout(finish, 500);
  })();
}
