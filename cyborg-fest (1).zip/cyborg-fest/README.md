# CYBORG//FEST 2026 — 3D Techfest Website

A scroll-driven, interactive 3D website for a fictional techfest. Scrolling flies the camera along a spline through a living cyborg eye-core, hex-gate tunnel, six clickable arena nodes, a DNA-helix timeline and a registration portal.

Built with **Three.js** (ES modules via CDN) + vanilla HTML/CSS/JS. No build step.

## Features
- 3D scroll-driven camera path with speed-based FOV warp
- Cyborg eye that tracks your cursor; click it for a shockwave + glitch
- Six interactive arena objects: hover to scan, click to open details
- Bloom post-processing, particles, instanced debris, animated helix
- Section-based accent colour shifts and sweep transitions
- Custom cursor, 3D-tilt panels, countdown, animated counters
- Responsive (mobile tap interactions), keyboard accessible, reduced-motion support
- WebGL fallback and adaptive resolution for low FPS

## Run locally
ES modules need a web server (opening the file directly won't work):

```bash
python3 -m http.server 8000
# or: npx serve .
```
Open http://localhost:8000

## Customise
Edit `js/config.js` — dates, venue, events, prizes, schedule, registration link and contact email.

## Structure
```
index.html        markup
css/style.css     styles
js/config.js      content
js/scene.js       Three.js scene
js/main.js        UI, scroll, interactions
```

## Deploy (GitHub Pages)
Push to `main`, then in the repo go to **Settings → Pages → Source: GitHub Actions**. The included workflow publishes the site automatically.

## License
MIT © Ayush Jain
